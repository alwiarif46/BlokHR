import { Router, Request, Response } from 'express';
import type { Logger } from 'pino';
import type { DatabaseEngine } from '../db/engine';
import { AppError, asyncHandler } from '../app';
import { SettingsRepository } from '../repositories/settings-repository';
import { LeaveRepository } from '../repositories/leave-repository';
import { RegularizationRepository } from '../repositories/regularization-repository';
import { BdMeetingRepository } from '../repositories/bd-meeting-repository';
import { MeetingRepository } from '../repositories/meeting-repository';
import { SettingsService } from '../services/settings-service';

/**
 * Settings & Roles routes:
 *   GET  /api/settings                — master settings bundle
 *   PUT  /api/members/:id             — update member profile
 *   GET  /api/user-roles?email=       — resolve user's roles
 *   GET  /api/pending-actions         — pending action counts
 *   GET  /api/pending-actions-detail  — pending action detail
 *   GET  /api/employee-of-month       — current EOM
 */
export function createSettingsRouter(db: DatabaseEngine, logger: Logger): Router {
  const router = Router();
  const settingsRepo = new SettingsRepository(db);
  const leaveRepo = new LeaveRepository(db);
  const regRepo = new RegularizationRepository(db);
  const bdMeetingRepo = new BdMeetingRepository(db);
  const meetingRepo = new MeetingRepository(db);
  const service = new SettingsService(
    settingsRepo,
    leaveRepo,
    regRepo,
    bdMeetingRepo,
    meetingRepo,
    logger,
  );

  /** GET /api/settings — full settings bundle for frontend cache. */
  router.get(
    '/settings',
    asyncHandler(async (_req: Request, res: Response) => {
      const settings = await service.getSettings();
      res.json(settings);
    }),
  );

  /** PUT /api/members/:id — update a member's profile. */
  router.put(
    '/members/:id',
    asyncHandler(async (req: Request, res: Response) => {
      const { id } = req.params;
      const fields = req.body as Record<string, unknown>;

      if (!fields || typeof fields !== 'object') {
        throw new AppError('Request body must be a JSON object', 400);
      }

      const result = await service.updateMember(id, fields);

      if (!result.success) {
        throw new AppError(result.error ?? 'Failed to update member', 400);
      }

      res.json(result);
    }),
  );

  /** GET /api/user-roles?email= — resolve a user's roles across all scopes. */
  router.get(
    '/user-roles',
    asyncHandler(async (req: Request, res: Response) => {
      const email = req.query.email as string | undefined;
      if (!email) throw new AppError('email query parameter required', 400);

      const roles = await service.getUserRoles(email.toLowerCase().trim());
      res.json(roles);
    }),
  );

  /** GET /api/pending-actions — counts for the pending badge. */
  router.get(
    '/pending-actions',
    asyncHandler(async (_req: Request, res: Response) => {
      const counts = await service.getPendingCounts();
      res.json(counts);
    }),
  );

  /** GET /api/pending-actions-detail — full detail for the pending modal. */
  router.get(
    '/pending-actions-detail',
    asyncHandler(async (_req: Request, res: Response) => {
      const detail = await service.getPendingDetail();
      res.json(detail);
    }),
  );

  /** GET /api/employee-of-month — current employee of the month. */
  router.get(
    '/employee-of-month',
    asyncHandler(async (_req: Request, res: Response) => {
      const eom = await service.getEmployeeOfMonth();
      res.json(eom);
    }),
  );

  return router;
}
